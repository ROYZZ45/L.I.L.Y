const puppeteer = require('puppeteer-core');

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const out = [];
const log = (...a) => out.push(a.join(' '));

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream',
      '--autoplay-policy=no-user-gesture-required',
    ],
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 960 });

  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push('console: ' + msg.text());
  });
  page.on('requestfailed', (req) => {
    const url = req.url();
    if (url.includes('localhost')) errors.push('requestfailed: ' + url + ' ' + req.failure()?.errorText);
  });

  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle2', timeout: 30000 });
  await new Promise((r) => setTimeout(r, 3000));

  // Did the modules boot?
  const boot = await page.evaluate(() => ({
    hasCore: typeof window.LilyCore !== 'undefined',
    hasVoice: typeof window.LilyVoice !== 'undefined',
    hasVision: typeof window.LilyVision !== 'undefined',
    hasActions: typeof window.LilyActions !== 'undefined',
    hasApp: typeof window.LilyApp !== 'undefined',
    orbState: document.getElementById('orb')?.dataset.state,
    status: document.getElementById('statusText')?.textContent,
    tf: typeof window.tf !== 'undefined',
    coco: typeof window.cocoSsd !== 'undefined',
    yt: typeof window.YT !== 'undefined',
  }));
  log('BOOT', JSON.stringify(boot, null, 2));

  // Is the orb actually visible and sized?
  const orbBox = await page.evaluate(() => {
    const o = document.getElementById('orb');
    const r = o.getBoundingClientRect();
    const core = getComputedStyle(document.querySelector('.orb-core'));
    return { w: Math.round(r.width), h: Math.round(r.height), bg: core.backgroundImage.slice(0, 60) };
  });
  log('ORB', JSON.stringify(orbBox));

  // Layout sanity: do panels overlap or overflow?
  const layout = await page.evaluate(() => {
    const ids = ['orb', 'transcriptPanel', 'cameraPanel', 'listenBtn', 'hint'];
    const rects = {};
    for (const id of ids) {
      const e = document.getElementById(id);
      if (!e) { rects[id] = 'MISSING'; continue; }
      const r = e.getBoundingClientRect();
      rects[id] = `${Math.round(r.x)},${Math.round(r.y)} ${Math.round(r.width)}x${Math.round(r.height)}`;
    }
    return { rects, scrollW: document.documentElement.scrollWidth, clientW: document.documentElement.clientWidth };
  });
  log('LAYOUT', JSON.stringify(layout, null, 2));

  // Exercise the assistant end to end (text path, no mic needed).
  await page.evaluate(() => window.LilyApp.handleUtterance('What is the capital of France? Answer in one short sentence.'));
  await new Promise((r) => setTimeout(r, 9000));
  const convo = await page.evaluate(() => ({
    user: document.querySelector('#userBubble p')?.textContent,
    lily: document.querySelector('#lilyBubble p')?.textContent,
  }));
  log('CONVO', JSON.stringify(convo));

  // YouTube tool -> inline player
  await page.evaluate(() => window.LilyApp.handleUtterance('Play despacito on youtube'));
  await new Promise((r) => setTimeout(r, 12000));
  const yt = await page.evaluate(() => ({
    mediaHidden: document.getElementById('mediaPanel').hidden,
    title: document.getElementById('mediaTitle').textContent,
    hasIframe: !!document.querySelector('#player iframe'),
    lily: document.querySelector('#lilyBubble p')?.textContent,
  }));
  log('YOUTUBE', JSON.stringify(yt));

  // Timer tool
  await page.evaluate(() => window.LilyApp.handleUtterance('Set a timer for 90 seconds'));
  await new Promise((r) => setTimeout(r, 9000));
  const timer = await page.evaluate(() => ({
    hidden: document.getElementById('timerPanel').hidden,
    readout: document.getElementById('timerReadout').textContent,
  }));
  log('TIMER', JSON.stringify(timer));

  await page.screenshot({ path: 'd:/L.I.L.Y/_shot_main.png' });

  // Camera + detector
  await page.evaluate(() => window.LilyVision.startCamera());
  await new Promise((r) => setTimeout(r, 8000));
  const cam = await page.evaluate(() => ({
    on: window.LilyCore.state.cameraOn,
    modelStatus: document.getElementById('modelStatus')?.textContent,
    videoW: document.getElementById('cam')?.videoWidth,
    fps: document.getElementById('fps')?.textContent,
  }));
  log('CAMERA', JSON.stringify(cam));
  await page.screenshot({ path: 'd:/L.I.L.Y/_shot_cam.png' });

  log('ERRORS', errors.length ? JSON.stringify(errors, null, 2) : 'none');
  await browser.close();
  require('fs').writeFileSync('d:/L.I.L.Y/_ui_out.txt', out.join('\n'));
})().catch((e) => {
  out.push('FATAL ' + e.message);
  require('fs').writeFileSync('d:/L.I.L.Y/_ui_out.txt', out.join('\n'));
  console.error(e);
});

(async () => {
  const base = 'http://localhost:3000';
  for (const p of ['/', '/style.css', '/js/core.js', '/js/voice.js', '/js/vision.js', '/js/actions.js', '/js/app.js', '/api/health', '/api/tools']) {
    try {
      const r = await fetch(base + p);
      const t = await r.text();
      log(p, '=>', r.status, 'len', t.length, 'ctype', r.headers.get('content-type'));
      if (p === '/api/health') log('   body:', t);
    } catch (e) { log(p, 'ERR', e.message); }
  }
  // Verify the HTML references every module.
  const html = await (await fetch(base + '/')).text();
  for (const src of ['js/core.js', 'js/voice.js', 'js/vision.js', 'js/actions.js', 'js/app.js', 'style.css']) {
    log('html refs', src, html.includes(src) ? 'OK' : 'MISSING');
  }
  // Check every element id referenced by core.js exists in the HTML.
  const ids = [...html.matchAll(/id="([^"]+)"/g)].map((m) => m[1]);
  const core = await (await fetch(base + '/js/core.js')).text();
  const wanted = [...core.matchAll(/\$\('([^']+)'\)/g)].map((m) => m[1]);
  for (const id of wanted) log('id', id, ids.includes(id) ? 'OK' : 'MISSING');

  require('fs').writeFileSync('d:/L.I.L.Y/_check_out.txt', out.join('\n'));
})();
