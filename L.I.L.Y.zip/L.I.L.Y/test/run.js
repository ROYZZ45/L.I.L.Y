'use strict';

/**
 * Smoke tests for the Lily backend. Run with: npm test
 * Requires a valid GROQ_API_KEY in .env and network access.
 */

const assert = require('assert');
const path = require('path');
const zlib = require('zlib');

/** Build a small solid-colour PNG so the vision endpoint has a valid image. */
function makePng(width, height, [r, g, b]) {
  const crc32 = (buf) => {
    let c;
    let crc = 0xffffffff;
    for (let n = 0; n < buf.length; n += 1) {
      c = (crc ^ buf[n]) & 0xff;
      for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      crc = c ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  };

  const chunk = (type, data) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const typed = Buffer.concat([Buffer.from(type, 'ascii'), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(typed));
    return Buffer.concat([len, typed, crc]);
  };

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 2; // colour type: truecolour

  const raw = Buffer.alloc(height * (1 + width * 3));
  for (let y = 0; y < height; y += 1) {
    const offset = y * (1 + width * 3);
    raw[offset] = 0; // filter: none
    for (let x = 0; x < width; x += 1) {
      raw[offset + 1 + x * 3] = r;
      raw[offset + 2 + x * 3] = g;
      raw[offset + 3 + x * 3] = b;
    }
  }

  const png = Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ]);

  return png.toString('base64');
}

// A 64x64 blue square - large enough for the vision model.
const IMAGE_64 = makePng(64, 64, [20, 60, 200]);

process.chdir(path.join(__dirname, '..'));
require('dotenv').config();

const app = require('../server/index');

let server;
let baseUrl;

const results = [];

/** Pause so we stay inside the Groq free-tier rate limits. */
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function test(name, fn) {
  try {
    await fn();
    results.push({ name, ok: true });
    console.log(`  PASS  ${name}`);
  } catch (err) {
    results.push({ name, ok: false, error: err.message });
    console.log(`  FAIL  ${name}\n        ${err.message}`);
  }
  await wait(1200);
}

async function get(pathname) {
  const response = await fetch(`${baseUrl}${pathname}`);
  const body = await response.json().catch(() => ({}));
  return { status: response.status, body };
}

async function post(pathname, payload) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const body = await response.json().catch(() => ({}));
  return { status: response.status, body };
}

async function main() {
  server = app.listen(0);
  await new Promise((resolve) => server.once('listening', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;

  console.log('\nLily backend tests\n');

  await test('health endpoint reports the key is configured', async () => {
    const { status, body } = await get('/api/health');
    assert.strictEqual(status, 200);
    assert.strictEqual(body.ok, true);
    assert.strictEqual(body.apiKeyConfigured, true);
  });

  await test('web search returns results', async () => {
    const { status, body } = await get('/api/search?q=capital%20of%20france');
    assert.strictEqual(status, 200);
    assert.ok(body.results.length > 0, 'expected at least one result');
    assert.ok(/^https?:\/\//.test(body.results[0].url), 'expected a direct URL');
    assert.ok(body.results[0].title.length > 0);
  });

  await test('youtube search returns playable videos', async () => {
    const { status, body } = await get('/api/youtube?q=despacito');
    assert.strictEqual(status, 200);
    assert.ok(body.videos.length > 0, 'expected at least one video');
    assert.match(body.videos[0].id, /^[\w-]{11}$/);
    assert.ok(body.videos[0].embedUrl.includes(body.videos[0].id));
  });

  await test('weather lookup returns current conditions', async () => {
    const { status, body } = await get('/api/weather?location=Mumbai');
    assert.strictEqual(status, 200);
    assert.ok(body.temperatureC !== undefined);
    assert.ok(typeof body.description === 'string' && body.description.length > 0);
  });

  await test('chat answers a general question', async () => {
    const { status, body } = await post('/api/chat', {
      message: 'In one short sentence, what is the capital of Japan?',
      sessionId: 'test-general',
    });
    assert.strictEqual(status, 200);
    assert.strictEqual(body.status, 'done');
    assert.ok(body.reply.length > 0, 'expected a reply');
    assert.ok(/tokyo/i.test(body.reply), `expected "Tokyo" in: ${body.reply}`);
  });

  await test('chat requests the open_tab tool', async () => {
    const { status, body } = await post('/api/chat', {
      message: 'Open wikipedia.org in a new tab',
      sessionId: 'test-tab',
    });
    assert.strictEqual(status, 200);
    assert.strictEqual(body.status, 'action_required');
    const action = body.actions.find((a) => a.name === 'open_tab');
    assert.ok(action, 'expected an open_tab action');
    assert.match(action.url, /^https?:\/\//);
  });

  await test('chat requests the play_youtube tool', async () => {
    const { status, body } = await post('/api/chat', {
      message: 'Play despacito on youtube',
      sessionId: 'test-yt',
    });
    assert.strictEqual(status, 200);
    assert.strictEqual(body.status, 'action_required');
    const action = body.actions.find((a) => a.name === 'play_youtube');
    assert.ok(action, 'expected a play_youtube action');
    assert.ok(action.query.length > 0);
  });

  await test('chat requests the look_at_camera tool', async () => {
    const { status, body } = await post('/api/chat', {
      message: 'What do you see in front of you?',
      sessionId: 'test-cam',
    });
    assert.strictEqual(status, 200);
    assert.strictEqual(body.status, 'action_required');
    const action = body.actions.find((a) => a.name === 'look_at_camera');
    assert.ok(action, 'expected a look_at_camera action');
  });

  await test('action results resume the conversation', async () => {
    const first = await post('/api/chat', {
      message: 'Open wikipedia.org in a new tab',
      sessionId: 'test-resume',
    });
    const action = first.body.actions.find((a) => a.name === 'open_tab');
    assert.ok(action);

    const { status, body } = await post('/api/chat', {
      sessionId: 'test-resume',
      actionResults: [{ toolCallId: action.toolCallId, result: { ok: true, opened: action.url } }],
    });
    assert.strictEqual(status, 200);
    assert.strictEqual(body.status, 'done');
    assert.ok(body.reply.length > 0);
  });

  await test('vision endpoint describes an image', async () => {
    const { status, body } = await post('/api/vision', {
      image: `data:image/png;base64,${IMAGE_64}`,
      question: 'What colour dominates this image? Answer in one word.',
    });
    assert.strictEqual(status, 200);
    assert.ok(body.description.length > 0, 'expected a description');
  });

  await test('transcribe rejects an empty payload', async () => {
    const { status } = await post('/api/transcribe', {});
    assert.strictEqual(status, 400);
  });

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed\n`);

  server.close();
  process.exit(failed.length ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  if (server) server.close();
  process.exit(1);
});
