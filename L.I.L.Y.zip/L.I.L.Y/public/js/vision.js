/**
 * Live camera preview with on-device object detection (TensorFlow.js coco-ssd),
 * plus a still-frame capture used by the "look at camera" tool.
 */
(function initVision(global) {
  'use strict';

  const { state, el, toast, api } = global.LilyCore;

  const MODEL_URL = 'https://storage.googleapis.com/tfjs-models/savedmodel/ssdlite_mobilenet_v2/model.json';

  const vision = {
    model: null,
    loading: false,
    running: false,
    stream: null,
    rafId: null,
    lastVideoTime: -1,
    labels: [],
  };

  async function loadDetector() {
    if (vision.model || vision.loading) return vision.model;

    if (!window.cocoSsd || !window.tf) {
      el.modelStatus.textContent = 'Detector unavailable (CDN blocked)';
      return null;
    }

    vision.loading = true;
    el.modelStatus.textContent = 'Loading detector…';
    try {
      vision.model = await window.cocoSsd.load({
        base: 'lite_mobilenet_v2',
        modelUrl: MODEL_URL,
      });
      el.modelStatus.textContent = 'Detector ready';
    } catch (err) {
      el.modelStatus.textContent = 'Detector failed to load';
      toast(`Object detection unavailable: ${err.message}`);
    } finally {
      vision.loading = false;
    }
    return vision.model;
  }

  function drawBoxes(predictions) {
    const canvas = el.overlay;
    const video = el.cam;
    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, width, height);
    ctx.lineWidth = Math.max(2, width / 320);
    ctx.font = `${Math.max(13, Math.round(width / 38))}px Inter, system-ui, sans-serif`;
    ctx.textBaseline = 'top';

    for (const prediction of predictions) {
      const [x, y, w, h] = prediction.bbox;
      const label = `${prediction.class} ${Math.round(prediction.score * 100)}%`;
      const labelHeight = Math.max(18, Math.round(width / 34));

      ctx.fillStyle = 'rgba(139, 125, 255, 0.16)';
      ctx.strokeStyle = '#8b7dff';
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, 6);
      ctx.fill();
      ctx.stroke();

      const textWidth = ctx.measureText(label).width;
      ctx.fillStyle = 'rgba(139, 125, 255, 0.9)';
      ctx.beginPath();
      ctx.roundRect(x, Math.max(0, y - labelHeight), textWidth + 12, labelHeight, 5);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillText(label, x + 6, Math.max(0, y - labelHeight) + 3);
    }
  }

  function updateLabels(predictions) {
    const names = predictions.map((p) => p.class);
    const changed = names.join(',') !== vision.labels.join(',');
    vision.labels = names;

    if (!names.length) {
      el.detected.hidden = true;
      el.detected.textContent = '';
      return;
    }

    el.detected.hidden = false;
    el.detected.textContent = '';
    for (const name of names) {
      const tag = document.createElement('span');
      tag.textContent = name;
      el.detected.appendChild(tag);
    }

    if (changed) {
      el.modelStatus.textContent = `Seeing: ${names.join(', ')}`;
    }
  }

  async function detectionLoop() {
    if (!vision.running) return;
    const video = el.cam;

    if (video.readyState >= 2 && video.currentTime !== vision.lastVideoTime && vision.model) {
      vision.lastVideoTime = video.currentTime;
      const started = performance.now();
      try {
        const predictions = await vision.model.detect(video);
        drawBoxes(predictions);
        updateLabels(predictions);
        const elapsed = performance.now() - started;
        el.fps.textContent = `${Math.round(1000 / Math.max(elapsed, 1))} fps`;
      } catch (err) {
        el.modelStatus.textContent = `Detection error: ${err.message}`;
      }
    }

    vision.rafId = requestAnimationFrame(detectionLoop);
  }

  async function startCamera() {
    if (state.cameraOn) return;
    try {
      vision.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 960 }, height: { ideal: 720 } },
        audio: false,
      });
      el.cam.srcObject = vision.stream;
      await el.cam.play();

      state.cameraOn = true;
      el.viewportEmpty.hidden = true;
      el.camToggle.textContent = 'Stop camera';
      el.camToggle.classList.add('on');

      vision.running = true;
      vision.lastVideoTime = -1;
      await loadDetector();
      detectionLoop();
    } catch (err) {
      toast(`Camera unavailable: ${err.message}`);
      el.camToggle.textContent = 'Start camera';
      el.camToggle.classList.remove('on');
    }
  }

  function stopCamera() {
    vision.running = false;
    if (vision.rafId) cancelAnimationFrame(vision.rafId);
    vision.rafId = null;

    if (vision.stream) {
      vision.stream.getTracks().forEach((track) => track.stop());
      vision.stream = null;
    }
    el.cam.srcObject = null;

    state.cameraOn = false;
    el.viewportEmpty.hidden = false;
    el.camToggle.textContent = 'Start camera';
    el.camToggle.classList.remove('on');
    el.detected.hidden = true;
    el.detected.textContent = '';
    el.fps.textContent = '';
    el.modelStatus.textContent = vision.model ? 'Detector ready' : 'Detector idle';

    const ctx = el.overlay.getContext('2d');
    ctx.clearRect(0, 0, el.overlay.width, el.overlay.height);
  }

  /**
   * Capture a still frame from the camera.
   * @returns {{image?: string, question: string, error?: string}}
   */
  async function captureFrame(question) {
    if (!state.cameraOn || !el.cam.videoWidth) {
      return { error: 'The camera is not running, so I cannot see anything yet.' };
    }

    const canvas = document.createElement('canvas');
    const maxSide = 768;
    const scale = Math.min(1, maxSide / Math.max(el.cam.videoWidth, el.cam.videoHeight));
    canvas.width = Math.round(el.cam.videoWidth * scale);
    canvas.height = Math.round(el.cam.videoHeight * scale);

    const ctx = canvas.getContext('2d');
    ctx.drawImage(el.cam, 0, 0, canvas.width, canvas.height);

    return {
      image: canvas.toDataURL('image/jpeg', 0.82),
      question: question || 'What do you see in this image?',
    };
  }

  /** Ask the server-side vision model about the current camera view. */
  async function describeCamera(question) {
    const capture = await captureFrame(question);
    if (capture.error) return { ok: false, error: capture.error };

    const reply = await api('/api/vision', {
      method: 'POST',
      body: { image: capture.image, question: capture.question },
    });

    return { ok: true, description: reply.description };
  }

  global.LilyVision = { startCamera, stopCamera, describeCamera, captureFrame, vision };
})(window);
