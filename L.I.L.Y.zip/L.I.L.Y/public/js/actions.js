/**
 * Browser side effects Lily can perform: opening tabs, playing YouTube,
 * running a timer, and looking through the camera.
 */
(function initActions(global) {
  'use strict';

  const { state, el, api } = global.LilyCore;

  /* ================= YouTube ================= */

  let ytReady = false;
  const ytCallbacks = [];

  /** Called by the YouTube iframe API once it has loaded. */
  function onYouTubeIframeReady() {
    ytReady = true;
    while (ytCallbacks.length) ytCallbacks.shift()();
  }

  // The IFrame API looks for this global by name.
  window.onYouTubeIframeAPIReady = onYouTubeIframeReady;

  function whenYouTubeReady() {
    if (ytReady) return Promise.resolve();
    // The API script may already be loaded and fired before we attached.
    if (window.YT && typeof window.YT.Player === 'function') {
      ytReady = true;
      return Promise.resolve();
    }
    // Never hang the turn waiting for the API.
    return Promise.race([
      new Promise((resolve) => ytCallbacks.push(resolve)),
      new Promise((resolve) => setTimeout(resolve, 6000)),
    ]).then(() => {
      ytReady = true;
    });
  }

  function ensureYouTubePlayer(videoId, title) {
    if (!window.YT || typeof window.YT.Player !== 'function') {
      // Fall back to a plain embed so playback still works.
      el.player.innerHTML = `<iframe src="https://www.youtube.com/embed/${encodeURIComponent(
        videoId
      )}?autoplay=1&rel=0" title="${escapeHtml(title || 'YouTube player')}" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
      el.mediaPanel.hidden = false;
      el.mediaTitle.textContent = title || 'Now playing';
      return;
    }

    if (!el.player.dataset.videoId) {
      el.player.innerHTML = '';
      state.youtubePlayer = new window.YT.Player(el.player, {
        height: '100%',
        width: '100%',
        videoId,
        playerVars: { autoplay: 1, rel: 0, modestbranding: 1 },
        events: {
          onReady: (event) => {
            event.target.playVideo();
          },
          onError: (event) => {
            // Fall back to a plain embed if the API player fails.
            el.player.innerHTML = `<iframe src="https://www.youtube.com/embed/${encodeURIComponent(
              videoId
            )}?autoplay=1" title="${escapeHtml(title || 'YouTube player')}" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
            void event;
          },
        },
      });
    } else {
      state.youtubePlayer.loadVideoById(videoId);
      state.youtubePlayer.playVideo();
    }

    el.mediaPanel.hidden = false;
    el.mediaTitle.textContent = title || 'Now playing';
  }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, (ch) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[ch]));
  }

  async function playOnYouTube(query) {
    const data = await api(`/api/youtube?q=${encodeURIComponent(query)}`);
    const videos = data.videos || [];

    if (!videos.length) {
      throw new Error(`I could not find anything on YouTube for “${query}”.`);
    }

    const first = videos[0];
    await whenYouTubeReady();
    ensureYouTubePlayer(first.id, first.title);

    return {
      playing: true,
      title: first.title,
      channel: first.channel,
      duration: first.duration,
      url: first.url,
      alternatives: videos.slice(1, 3).map((v) => ({ title: v.title, channel: v.channel, url: v.url })),
    };
  }

  /* ================= Timer ================= */

  function formatTime(ms) {
    const total = Math.max(0, Math.round(ms / 1000));
    const minutes = String(Math.floor(total / 60)).padStart(2, '0');
    const seconds = String(total % 60).padStart(2, '0');
    return `${minutes}:${seconds}`;
  }

  function startTimer(seconds, label) {
    clearInterval(state.timerHandle);
    state.timerEndsAt = Date.now() + seconds * 1000;

    el.timerPanel.hidden = false;
    el.timerPanel.classList.remove('done');

    const tick = () => {
      const remaining = state.timerEndsAt - Date.now();
      el.timerReadout.textContent = formatTime(remaining);
      if (remaining <= 0) {
        clearInterval(state.timerHandle);
        el.timerPanel.classList.add('done');
        el.timerReadout.textContent = 'Done';
        global.LilyVoice.speak(label ? `Your ${label} timer is done.` : 'Timer is done.');
      }
    };

    tick();
    state.timerHandle = setInterval(tick, 250);
    return { started: true, seconds, label: label || '' };
  }

  function clearTimer() {
    clearInterval(state.timerHandle);
    state.timerHandle = null;
    el.timerPanel.hidden = true;
    el.timerPanel.classList.remove('done');
    return { cleared: true };
  }

  /* ================= tool execution ================= */

  /** Execute one browser-side tool and return the result for the model. */
  async function runClientAction(action) {
    switch (action.name) {
      case 'open_tab': {
        const url = String(action.url || '').trim();
        if (!/^https?:\/\//i.test(url)) {
          return { ok: false, error: 'That was not a valid web address.' };
        }
        window.open(url, '_blank', 'noopener,noreferrer');
        return { ok: true, opened: url };
      }

      case 'play_youtube': {
        try {
          return await playOnYouTube(action.query || '');
        } catch (err) {
          return { ok: false, error: err.message };
        }
      }

      case 'set_timer': {
        const seconds = Math.max(1, Math.round(Number(action.seconds) || 0));
        if (!seconds) return { ok: false, error: 'No timer duration was given.' };
        return startTimer(seconds, action.label);
      }

      case 'look_at_camera': {
        try {
          return await global.LilyVision.describeCamera(action.question);
        } catch (err) {
          return { ok: false, error: err.message };
        }
      }

      default:
        return { ok: false, error: `Unsupported action ${action.name}` };
    }
  }

  global.LilyActions = { runClientAction, playOnYouTube, startTimer, clearTimer, onYouTubeIframeReady };
})(window);
