/**
 * Lily — main controller.
 *
 * Owns the assistant turn loop (model call -> browser actions -> final reply)
 * and wires up the UI controls.
 */
(function initApp(global) {
  'use strict';

  const { state, el, api, toast, setOrbState, setStatus, addBubble, showThinkingBubble, resetIdleUi } = global.LilyCore;

  /**
   * Send the user's message, run whatever the model asks for, then speak the
   * reply.
   */
  async function handleUtterance(message) {
    if (state.busy) return;
    state.busy = true;
    setOrbState('thinking');
    setStatus('Thinking…', 'busy');
    addBubble('user', message);
    showThinkingBubble();

    try {
      let response = await api('/api/chat', {
        method: 'POST',
        body: { message, sessionId: state.sessionId },
      });

      // The model may need the browser to do something before it can finish.
      let guard = 0;
      while (response.status === 'action_required' && guard < 4) {
        guard += 1;
        const results = [];
        for (const action of response.actions || []) {
          // eslint-disable-next-line no-await-in-loop
          const result = await global.LilyActions.runClientAction(action);
          results.push({ toolCallId: action.toolCallId, result });
        }
        response = await api('/api/chat', {
          method: 'POST',
          body: { sessionId: state.sessionId, actionResults: results },
        });
      }

      const reply = (response.reply || '').trim();
      const paragraph = el.lilyBubble.querySelector('p');
      paragraph.className = '';
      paragraph.textContent = reply || 'I am not sure what to say to that.';
      el.lilyBubble.hidden = false;
      global.LilyCore.scrollTranscript();

      await global.LilyVoice.speak(reply);
    } catch (err) {
      const paragraph = el.lilyBubble.querySelector('p');
      paragraph.className = '';
      paragraph.textContent = `Sorry, something went wrong: ${err.message}`;
      toast(err.message);
      setStatus('Something went wrong');
    } finally {
      state.busy = false;
      if (!state.speaking) resetIdleUi();
    }
  }

  /* ================= controls ================= */

  function bindEvents() {
    const listenBtn = el.listenBtn;

    listenBtn.addEventListener('pointerdown', async (event) => {
      event.preventDefault();
      try {
        await global.LilyVoice.startManual();
      } catch {
        /* toast already shown */
      }
    });

    const endManual = () => {
      if (global.LilyVoice.listener) global.LilyVoice.stopManual();
    };
    listenBtn.addEventListener('pointerup', endManual);
    listenBtn.addEventListener('pointerleave', endManual);
    listenBtn.addEventListener('pointercancel', endManual);

    // Tapping the orb starts a one-shot conversation.
    let orbTimer = null;
    el.orb.addEventListener('pointerdown', async () => {
      if (state.busy || state.speaking) return;
      try {
        await global.LilyVoice.startManual();
      } catch {
        return;
      }
      orbTimer = setTimeout(() => {
        if (global.LilyVoice.listener) global.LilyVoice.stopManual();
      }, 7000);
    });

    const clearOrbTimer = () => {
      clearTimeout(orbTimer);
    };
    el.orb.addEventListener('pointerup', clearOrbTimer);
    el.orb.addEventListener('pointerleave', clearOrbTimer);

    el.orb.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        el.orb.dispatchEvent(new PointerEvent('pointerdown'));
      }
    });

    // Wake word toggle.
    el.wakeToggle.addEventListener('click', () => {
      state.wakeEnabled = !state.wakeEnabled;
      localStorage.setItem('lily.wake', state.wakeEnabled ? 'on' : 'off');
      el.wakeToggle.setAttribute('aria-pressed', String(state.wakeEnabled));

      if (state.wakeEnabled) {
        global.LilyVoice.startWakeLoop();
        resetIdleUi();
      } else {
        global.LilyVoice.stopWakeLoop();
        setOrbState('idle');
        setStatus('Wake word off');
      }
    });

    // Mute toggle.
    el.muteToggle.addEventListener('click', () => {
      state.muted = !state.muted;
      localStorage.setItem('lily.mute', state.muted ? 'on' : 'off');
      el.muteToggle.setAttribute('aria-pressed', String(state.muted));
      el.muteIcon.textContent = state.muted ? '🔇' : '🔊';
      if (state.muted && window.speechSynthesis) window.speechSynthesis.cancel();
    });

    // Camera.
    el.camToggle.addEventListener('click', () => {
      if (state.cameraOn) global.LilyVision.stopCamera();
      else global.LilyVision.startCamera();
    });

    el.mediaClose.addEventListener('click', () => {
      el.mediaPanel.hidden = true;
      if (state.youtubePlayer && state.youtubePlayer.stopVideo) state.youtubePlayer.stopVideo();
    });

    el.timerClose.addEventListener('click', () => global.LilyActions.clearTimer());
  }


  /* ================= boot ================= */

  async function boot() {
    bindEvents();

    el.wakeToggle.setAttribute('aria-pressed', String(state.wakeEnabled));
    el.muteToggle.setAttribute('aria-pressed', String(state.muted));
    el.muteIcon.textContent = state.muted ? '🔇' : '🔊';

    setOrbState(state.wakeEnabled ? 'active' : 'idle');
    setStatus(state.wakeEnabled ? 'Say “Hey Lily”' : 'Wake word off');

    if (!navigator.mediaDevices || !window.MediaRecorder) {
      el.listenBtn.disabled = true;
      el.listenLabel.textContent = 'Voice unavailable';
      toast('This browser does not support microphone recording.');
    }

    if (state.wakeEnabled) {
      // The browser only grants the microphone after a user gesture.
      const begin = async () => {
        try {
          await global.LilyVoice.startWakeLoop();
        } catch {
          /* toast already shown */
        }
        window.removeEventListener('pointerdown', begin);
        window.removeEventListener('keydown', begin);
      };
      window.addEventListener('pointerdown', begin);
      window.addEventListener('keydown', begin);
    }

    try {
      const health = await api('/api/health');
      if (!health.apiKeyConfigured) {
        toast('GROQ_API_KEY is not configured on the server.');
      }
    } catch {
      toast('Could not reach the Lily server.');
    }
  }

  global.LilyApp = { handleUtterance, boot };
  document.addEventListener('DOMContentLoaded', boot);
})(window);
