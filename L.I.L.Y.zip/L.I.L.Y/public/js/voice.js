/**
 * Microphone handling: continuous listening for the wake word, push-to-talk
 * capture, and speech output via the browser Speech Synthesis API.
 */
(function initVoice(global) {
  'use strict';

  const { state, el, toast, setOrbState, setStatus, resetIdleUi, addBubble, transcribeAudio, blobToBase64, pickMimeType, findWakeWord } = global.LilyCore;

  /* ================= speech output ================= */

  const synth = window.speechSynthesis;

  function pickVoice() {
    if (!synth) return null;
    const voices = synth.getVoices();
    if (!voices.length) return null;
    const preferred = ['Google UK English Female', 'Samantha', 'Microsoft Aria', 'Microsoft Zira', 'Karen', 'Daniel'];
    for (const name of preferred) {
      const match = voices.find((v) => v.name === name);
      if (match) return match;
    }
    return voices.find((v) => v.lang && v.lang.startsWith('en')) || voices[0];
  }

  function speak(text) {
    if (!text) return Promise.resolve();
    if (state.muted || !synth) {
      addBubble('lily', text);
      return Promise.resolve();
    }

    return new Promise((resolve) => {
      try {
        synth.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        const voice = pickVoice();
        if (voice) utterance.voice = voice;
        utterance.rate = 1.03;
        utterance.pitch = 1.05;

        utterance.onstart = () => {
          state.speaking = true;
          setOrbState('speaking');
          setStatus('Speaking…', 'busy');
        };

        const done = () => {
          state.speaking = false;
          if (!state.busy) resetIdleUi();
          resolve();
        };

        utterance.onend = done;
        utterance.onerror = done;
        synth.speak(utterance);
      } catch {
        addBubble('lily', text);
        resolve();
      }
    });
  }


  /* ================= continuous wake word listener ================= */

  const listener = {
    stream: null,
    recorder: null,
    chunks: [],
    /** 'idle' -> looking for the wake word, 'capturing' -> recording a command. */
    phase: 'idle',
    pollTimer: null,
    /** Voice activity detection. */
    audioContext: null,
    analyser: null,
    level: 0,
    /** RMS above this counts as speech. */
    speechThreshold: 0.02,
    /** Silence after the last detected sound that ends a command. */
    silenceMs: 1600,
    lastSoundAt: 0,
    speechStartedAt: 0,
  };

  /** Attach an analyser so we can tell silence from speech. */
  async function attachLevelMeter(stream) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    try {
      listener.audioContext = new AudioCtx();
      const source = listener.audioContext.createMediaStreamSource(stream);
      listener.analyser = listener.audioContext.createAnalyser();
      listener.analyser.fftSize = 512;
      source.connect(listener.analyser);
    } catch {
      listener.analyser = null;
    }
  }

  /** Sample the current input level (0..1). */
  function readLevel() {
    if (!listener.analyser) return 0;
    const data = new Uint8Array(listener.analyser.frequencyBinCount);
    listener.analyser.getByteTimeDomainData(data);
    let sum = 0;
    for (let i = 0; i < data.length; i += 1) {
      const value = (data[i] - 128) / 128;
      sum += value * value;
    }
    return Math.sqrt(sum / data.length);
  }

  async function startListening() {
    if (listener.stream) return;

    try {
      listener.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
    } catch (err) {
      toast(`Microphone unavailable: ${err.message}`);
      throw err;
    }

    const mimeType = pickMimeType();
    listener.recorder = new MediaRecorder(listener.stream, mimeType ? { mimeType } : undefined);
    listener.chunks = [];
    listener.recorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) listener.chunks.push(event.data);
    };
    listener.recorder.start(250);
    await attachLevelMeter(listener.stream);
  }

  function stopListening() {
    clearInterval(listener.pollTimer);
    listener.pollTimer = null;

    if (listener.recorder && listener.recorder.state !== 'inactive') {
      listener.recorder.stop();
    }
    if (listener.stream) {
      listener.stream.getTracks().forEach((track) => track.stop());
      listener.stream = null;
    }
    if (listener.audioContext) {
      listener.audioContext.close().catch(() => {});
      listener.audioContext = null;
    }
    listener.analyser = null;
    listener.recorder = null;
    listener.chunks = [];
    listener.phase = 'idle';
  }

  /**
   * Transcribe the rolling buffer and look for the wake word.
   * While capturing a command we instead watch for silence and then send it.
   */
  async function pollListener() {
    if (!listener.recorder || listener.recorder.state !== 'recording') return;
    if (state.busy || state.speaking) return;

    listener.level = readLevel();

    if (listener.phase === 'capturing') {
      // Has the user stopped talking?
      if (listener.level >= listener.speechThreshold) {
        listener.lastSoundAt = Date.now();
      } else if (Date.now() - listener.lastSoundAt > listener.silenceMs) {
        await finishCapture();
      }
      return;
    }

    const mimeType = listener.recorder.mimeType || 'audio/webm';
    const snapshot = new Blob(listener.chunks, { type: mimeType });
    if (!snapshot.size) return;

    try {
      const base64 = await blobToBase64(snapshot);
      const text = await transcribeAudio(base64, mimeType);
      if (!text) return;

      const wake = findWakeWord(text);
      if (!wake.matched) return;

      // Drop the audio before the wake word so the command is clean.
      listener.phase = 'capturing';
      listener.chunks = [];
      listener.lastSoundAt = Date.now();
      listener.speechStartedAt = Date.now();
      setOrbState('listening');
      setStatus('Listening…', 'live');

      if (wake.command) {
        addBubble('user', wake.command);
        global.LilyApp.handleUtterance(wake.command);
      }
    } catch {
      /* transient STT errors are ignored while idling */
    }
  }
  async function finishCapture() {
    if (listener.phase !== 'capturing') return;
    listener.phase = 'idle';

    const mimeType = listener.recorder?.mimeType || 'audio/webm';
    const blob = new Blob(listener.chunks, { type: mimeType });
    listener.chunks = [];

    if (!blob.size) {
      resetIdleUi();
      return;
    }

    setOrbState('thinking');
    setStatus('Thinking…', 'busy');

    try {
      const base64 = await blobToBase64(blob);
      const text = await transcribeAudio(base64, mimeType);
      if (!text) {
        toast('I did not catch that.');
        resetIdleUi();
        return;
      }
      await global.LilyApp.handleUtterance(text);
    } catch (err) {
      toast(err.message);
      resetIdleUi();
    }
  }

  /** Start the wake word loop. */
  async function startWakeLoop() {
    if (!state.wakeEnabled) return;
    try {
      await startListening();
    } catch {
      setStatus('Microphone blocked');
      return;
    }

    clearInterval(listener.pollTimer);
    listener.pollTimer = setInterval(pollListener, 700);
  }

  function stopWakeLoop() {
    stopListening();
  }

  /* ================= push to talk ================= */

  let manualChunks = [];
  let manualRecorder = null;

  async function startManual() {
    if (manualRecorder) return;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mimeType = pickMimeType();
    manualRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    manualChunks = [];
    manualRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size) manualChunks.push(event.data);
    };
    manualRecorder.start(250);

    el.listenBtn.classList.add('recording');
    el.listenLabel.textContent = 'Listening…';
    setOrbState('listening');
    setStatus('Listening…', 'live');
  }

  async function stopManual() {
    if (!manualRecorder) return;
    const recorderRef = manualRecorder;
    const stream = recorderRef.stream;
    const mimeType = recorderRef.mimeType || 'audio/webm';

    await new Promise((resolve) => {
      recorderRef.onstop = resolve;
      recorderRef.stop();
    });
    stream.getTracks().forEach((track) => track.stop());

    const blob = new Blob(manualChunks, { type: mimeType });
    manualChunks = [];
    manualRecorder = null;
    el.listenBtn.classList.remove('recording');
    el.listenLabel.textContent = 'Hold to talk';

    if (!blob.size) return;

    setOrbState('thinking');
    setStatus('Thinking…', 'busy');
    try {
      const base64 = await blobToBase64(blob);
      const text = await transcribeAudio(base64, mimeType);
      if (!text) {
        toast('I did not catch that.');
        resetIdleUi();
        return;
      }
      await global.LilyApp.handleUtterance(text);
    } catch (err) {
      toast(err.message);
      resetIdleUi();
    }
  }

  global.LilyVoice = {
    speak,
    startWakeLoop,
    stopWakeLoop,
    finishCapture,
    startManual,
    stopManual,
    listener,
  };
})(window);
