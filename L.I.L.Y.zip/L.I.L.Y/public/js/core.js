/**
 * Shared state, DOM references and small helpers used across the Lily modules.
 */
(function initCore(global) {
  'use strict';

  const WAKE_ALIASES = [
    'hey lily',
    'hey lili',
    'hey lie',
    'hey lee',
    'hey liey',
    'a lily',
    'hey li',
    'hello lily',
    'ok lily',
  ];

  const state = {
    sessionId: localStorage.getItem('lily.session') || `s_${Math.random().toString(36).slice(2, 11)}`,
    wakeEnabled: localStorage.getItem('lily.wake') !== 'off',
    muted: localStorage.getItem('lily.mute') === 'on',
    listening: false,
    speaking: false,
    busy: false,
    cameraOn: false,
    timerHandle: null,
    timerEndsAt: 0,
    youtubePlayer: null,
  };

  localStorage.setItem('lily.session', state.sessionId);

  const $ = (id) => document.getElementById(id);

  const el = {
    orb: $('orb'),
    statusText: $('statusText'),
    statusDot: $('statusDot'),
    transcript: $('transcript'),
    userBubble: $('userBubble'),
    lilyBubble: $('lilyBubble'),
    toast: $('toast'),
    listenBtn: $('listenBtn'),
    listenLabel: $('listenLabel'),
    wakeToggle: $('wakeToggle'),
    muteToggle: $('muteToggle'),
    muteIcon: $('muteIcon'),
    camToggle: $('camToggle'),
    cam: $('cam'),
    overlay: $('overlay'),
    viewportEmpty: $('viewportEmpty'),
    detected: $('detected'),
    modelStatus: $('modelStatus'),
    fps: $('fps'),
    mediaPanel: $('mediaPanel'),
    mediaTitle: $('mediaTitle'),
    mediaClose: $('mediaClose'),
    player: $('player'),
    timerPanel: $('timerPanel'),
    timerReadout: $('timerReadout'),
    timerClose: $('timerClose'),
  };

  /* ---------------- UI helpers ---------------- */

  let toastTimer = null;
  function toast(message, ms = 4200) {
    el.toast.textContent = message;
    el.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      el.toast.hidden = true;
    }, ms);
  }

  function setOrbState(next) {
    el.orb.dataset.state = next;
  }

  function setStatus(text, mode = '') {
    el.statusText.textContent = text;
    el.statusDot.className = 'status-dot';
    if (mode) el.statusDot.classList.add(mode);
  }

  function scrollTranscript() {
    el.transcript.scrollTop = el.transcript.scrollHeight;
  }

  function addBubble(kind, text) {
    const bubble = kind === 'user' ? el.userBubble : el.lilyBubble;
    const paragraph = bubble.querySelector('p');
    paragraph.className = '';
    paragraph.textContent = text;
    bubble.hidden = false;
    scrollTranscript();
  }

  function showThinkingBubble() {
    el.lilyBubble.hidden = false;
    const paragraph = el.lilyBubble.querySelector('p');
    paragraph.className = 'dots';
    paragraph.textContent = '';
    scrollTranscript();
  }

  function resetIdleUi() {
    setOrbState(state.wakeEnabled ? 'active' : 'idle');
    setStatus(state.wakeEnabled ? 'Say “Hey Lily”' : 'Wake word off');
  }

  /* ---------------- server API ---------------- */

  async function api(path, options = {}) {
    const response = await fetch(path, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });

    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(payload.error || `Request failed with status ${response.status}`);
    }
    return payload;
  }

  async function transcribeAudio(base64, mimeType) {
    const data = await api('/api/transcribe', {
      method: 'POST',
      body: { audio: base64, mimeType },
    });
    return (data.text || '').trim();
  }

  /* ---------------- misc ---------------- */

  async function blobToBase64(blob) {
    const buffer = await blob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function pickMimeType() {
    const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    for (const type of candidates) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported(type)) return type;
    }
    return '';
  }

  function normalise(text) {
    return text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Look for the wake word in a transcript.
   * @returns {{matched: boolean, command: string}}
   */
  function findWakeWord(text) {
    const flat = normalise(text);

    for (const alias of WAKE_ALIASES) {
      const index = flat.indexOf(alias);
      if (index !== -1) {
        return { matched: true, command: flat.slice(index + alias.length).trim() };
      }
    }

    const lone = /\blily\b/.exec(flat);
    if (lone) {
      return { matched: true, command: flat.slice(lone.index + 4).trim() };
    }

    return { matched: false, command: '' };
  }

  global.LilyCore = {
    state,
    el,
    api,
    toast,
    setOrbState,
    setStatus,
    scrollTranscript,
    addBubble,
    showThinkingBubble,
    resetIdleUi,
    transcribeAudio,
    blobToBase64,
    pickMimeType,
    normalise,
    findWakeWord,
    WAKE_ALIASES,
  };
})(window);
