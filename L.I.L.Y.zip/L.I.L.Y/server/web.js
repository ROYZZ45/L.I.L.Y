'use strict';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

function decodeEntities(text = '') {
  return text
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(Number(d)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function stripTags(html = '') {
  return decodeEntities(html.replace(/<[^>]*>/g, '')).replace(/\s+/g, ' ').trim();
}

/** Bing wraps result URLs in a redirect with a base64 `u=a1...` parameter. */
function decodeBingUrl(href = '') {
  const raw = href.replace(/&amp;/g, '&');
  const match = /[?&]u=a1([^&]+)/.exec(raw);
  if (match) {
    try {
      const decoded = Buffer.from(match[1], 'base64').toString('utf8');
      if (/^https?:\/\//i.test(decoded)) return decoded;
    } catch {
      /* fall through to the raw href */
    }
  }
  if (/^https?:\/\//i.test(raw)) return raw;
  return raw;
}

async function fetchHtml(url) {
  const response = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Accept-Language': 'en-US,en;q=0.9',
      Accept: 'text/html,application/xhtml+xml',
    },
    redirect: 'follow',
  });
  if (!response.ok) throw new Error(`Request to ${new URL(url).host} failed with status ${response.status}`);
  return response.text();
}

/** Web search via Bing. Returns an array of { title, url, snippet }. */
async function webSearch(query, limit = 5) {
  const html = await fetchHtml(`https://www.bing.com/search?q=${encodeURIComponent(query)}&setmkt=en-US&setlang=en`);
  const blocks = html.split('<li class="b_algo"').slice(1);
  const results = [];

  for (const block of blocks) {
    const link = /<h2><a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/.exec(block);
    if (!link) continue;

    const url = decodeBingUrl(link[1]);
    if (!/^https?:\/\//i.test(url)) continue;

    const snippetMatch = /<p[^>]*>([\s\S]*?)<\/p>/.exec(block);
    const snippet = snippetMatch ? stripTags(snippetMatch[1]) : '';
    const title = stripTags(link[2]);

    if (!title) continue;
    results.push({ title, url, snippet: snippet.slice(0, 400) });
    if (results.length >= limit) break;
  }

  if (!results.length) {
    // Fallback: pull any outbound links with anchor text.
    const linkRe = /<h2><a[^>]*href="(https?:\/\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
    let match;
    while ((match = linkRe.exec(html)) && results.length < limit) {
      const title = stripTags(match[2]);
      if (!title) continue;
      results.push({ title, url: decodeBingUrl(match[1]), snippet: '' });
    }
  }

  return results;
}

/** Search YouTube and return the top matching videos. */
async function searchYouTube(query, limit = 5) {
  const html = await fetchHtml(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
  const blocks = html.split('"videoRenderer"').slice(1);
  const videos = [];
  const seen = new Set();

  for (const block of blocks) {
    const id = /"videoId":"([\w-]{11})"/.exec(block);
    if (!id || seen.has(id[1])) continue;
    seen.add(id[1]);

    const title = /"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"/.exec(block);
    const channel = /"ownerText":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"/.exec(block);
    const duration = /"lengthText":\{"accessibility":\{"accessibilityData":\{"label":"([^"]+)"/.exec(block);
    const views = /"viewCountText":\{"simpleText":"([^"]+)"/.exec(block);

    videos.push({
      id: id[1],
      title: title ? decodeEntities(title[1].replace(/\\u0026/g, '&').replace(/\\"/g, '"')) : 'Untitled',
      channel: channel ? decodeEntities(channel[1]) : '',
      duration: duration ? duration[1] : '',
      views: views ? views[1] : '',
      url: `https://www.youtube.com/watch?v=${id[1]}`,
      embedUrl: `https://www.youtube.com/embed/${id[1]}`,
    });
    if (videos.length >= limit) break;
  }

  return videos;
}

/** Quick encyclopedia lookup, used to enrich answers with facts. */
async function wikipediaSummary(title, lang = 'en') {
  const url = `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
  try {
    const response = await fetch(url, { headers: { 'User-Agent': UA } });
    if (!response.ok) return null;
    const json = await response.json();
    return {
      title: json.title,
      extract: json.extract,
      url: json.content_urls?.desktop?.page,
      thumbnail: json.thumbnail?.source,
    };
  } catch {
    return null;
  }
}

/** Current weather via wttr.in (no API key required). */
async function getWeather(location) {
  const url = `https://wttr.in/${encodeURIComponent(location)}?format=j1`;
  const response = await fetch(url, { headers: { 'User-Agent': 'curl/8.0' } });
  if (!response.ok) throw new Error(`Weather lookup failed with status ${response.status}`);
  const data = await response.json();
  const current = data.current_condition?.[0];
  if (!current) throw new Error('No weather data returned');

  const area = data.nearest_area?.[0];
  const region = area?.areaName?.[0]?.value || location;
  const country = area?.country?.[0]?.value || '';

  return {
    location: country ? `${region}, ${country}` : region,
    temperatureC: current.temp_C,
    temperatureF: current.temp_F,
    feelsLikeC: current.FeelsLikeC,
    feelsLikeF: current.FeelsLikeF,
    description: current.weatherDesc?.[0]?.value,
    humidity: current.humidity,
    windKph: current.windspeedKmph,
    visibility: current.visibility,
    uvIndex: current.uvIndex,
    observedAt: current.localObsDateTime,
  };
}

module.exports = { webSearch, searchYouTube, wikipediaSummary, getWeather, stripTags, decodeEntities, decodeBingUrl };
