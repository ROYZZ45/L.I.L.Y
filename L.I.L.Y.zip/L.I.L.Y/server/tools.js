'use strict';

/**
 * Tool catalogue for the model. `client: true` means the tool produces a
 * browser side effect and is executed by the front-end, everything else runs
 * on the server and is fed back to the model as a tool result.
 */
const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'open_tab',
      description:
        'Open a URL in a new browser tab. Use for websites the user asks to visit. Provide a full absolute URL starting with http:// or https://.',
      parameters: {
        type: 'object',
        properties: {
          url: { type: 'string', description: 'Absolute URL to open, e.g. https://en.wikipedia.org/wiki/Paris' },
        },
        required: ['url'],
      },
    },
    client: true,
  },
  {
    type: 'function',
    function: {
      name: 'search_web',
      description:
        'Search the internet and return a list of results with titles, URLs and snippets. Use for facts, news and general questions that benefit from live data.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'The search query' },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'play_youtube',
      description:
        'Search YouTube for a video and play it inside the assistant player. Use whenever the user asks to play, watch, listen to music or a video.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'What to play, e.g. "despacito" or "lo-fi beats"' },
        },
        required: ['query'],
      },
    },
    client: true,
  },
  {
    type: 'function',
    function: {
      name: 'get_weather',
      description: 'Get the current weather conditions for a city or place.',
      parameters: {
        type: 'object',
        properties: {
          location: { type: 'string', description: 'City or place name, e.g. "Mumbai"' },
        },
        required: ['location'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_wikipedia_summary',
      description: 'Look up a short encyclopedic summary about a person, place, company or concept.',
      parameters: {
        type: 'object',
        properties: {
          topic: { type: 'string', description: 'The topic to look up' },
        },
        required: ['topic'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'set_timer',
      description: 'Start a countdown timer for a number of seconds.',
      parameters: {
        type: 'object',
        properties: {
          seconds: { type: 'number', description: 'Duration of the timer in seconds' },
          label: { type: 'string', description: 'Optional label describing the timer' },
        },
        required: ['seconds'],
      },
    },
    client: true,
  },
  {
    type: 'function',
    function: {
      name: 'look_at_camera',
      description:
        'Look through the live camera feed and describe what is in front of the user. Use this when the user asks what the camera sees, or asks to identify an object.',
      parameters: {
        type: 'object',
        properties: {
          question: { type: 'string', description: 'What the user wants to know about the camera view' },
        },
        required: ['question'],
      },
    },
    client: true,
  },
];

/** Tools sent to Groq. */
function toolSchemas() {
  return TOOLS.map(({ type, function: fn }) => ({ type, function: fn }));
}

/** Names of tools the browser must run. */
function clientToolNames() {
  return TOOLS.filter((t) => t.client).map((t) => t.function.name);
}

module.exports = { TOOLS, toolSchemas, clientToolNames };
