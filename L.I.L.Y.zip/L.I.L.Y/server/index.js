'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');

const { transcribe, speak, describeImage, apiKey } = require('./groq');
const { runTurn, resetSession } = require('./agent');
const { webSearch, searchYouTube, getWeather } = require('./web');
const { toolSchemas } = require('./tools');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

app.use(express.json({ limit: '2mb' }));
app.use(express.static(PUBLIC_DIR, { extensions: ['html'] }));

/** Wrap an async handler so rejections become clean JSON errors. */
const wrap = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    apiKeyConfigured: Boolean(apiKey()),
    chatModel: process.env.GROQ_CHAT_MODEL || 'qwen/qwen3.8-27b',
    sttModel: process.env.GROQ_STT_MODEL || 'whisper-large-v3-turbo',
    ttsModel: process.env.GROQ_TTS_MODEL || 'canopylabs/orpheus-v1-english',
    ttsAvailable: false,
  });
});

/** Transcribe a recorded utterance. */
app.post(
  '/api/transcribe',
  wrap(async (req, res) => {
    const { audio, mimeType, filename } = req.body || {};
    if (!audio) return res.status(400).json({ error: 'No audio payload received.' });

    const buffer = Buffer.from(audio, 'base64');
    if (!buffer.length) return res.status(400).json({ error: 'Audio payload was empty.' });

    const text = await transcribe(buffer, {
      filename: filename || 'audio.webm',
      mimeType: mimeType || 'audio/webm',
    });

    res.json({ text });
  })
);

/** Describe a camera frame (or any image) with the vision model. */
app.post(
  '/api/vision',
  wrap(async (req, res) => {
    const { image, question } = req.body || {};
    if (!image || typeof image !== 'string' || !image.startsWith('data:image/')) {
      return res.status(400).json({ error: 'Provide a data:image/... encoded image.' });
    }
    const description = await describeImage({ imageUrl: image, question });
    res.json({ description });
  })
);

/** Main assistant turn. */
app.post(
  '/api/chat',
  wrap(async (req, res) => {
    const { message, sessionId, actionResults } = req.body || {};
    if (!message && !(actionResults && actionResults.length)) {
      return res.status(400).json({ error: 'Provide a message or action results.' });
    }
    const result = await runTurn({ message, sessionId, actionResults: actionResults || [] });
    res.json(result);
  })
);

/** Reset the conversation for a session. */
app.post('/api/reset', (req, res) => {
  resetSession(req.body?.sessionId);
  res.json({ ok: true });
});

/** Text to speech - optional, requires the Groq model terms to be accepted. */
app.post(
  '/api/tts',
  wrap(async (req, res) => {
    const { text, voice } = req.body || {};
    if (!text) return res.status(400).json({ error: 'Provide text to speak.' });
    const { audio, contentType } = await speak(text, { voice });
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', audio.length);
    res.send(audio);
  })
);

/** Direct helper endpoints, also usable without the model. */
app.get(
  '/api/search',
  wrap(async (req, res) => {
    const query = String(req.query.q || '').trim();
    if (!query) return res.status(400).json({ error: 'Missing q parameter.' });
    res.json({ query, results: await webSearch(query, 6) });
  })
);

app.get(
  '/api/youtube',
  wrap(async (req, res) => {
    const query = String(req.query.q || '').trim();
    if (!query) return res.status(400).json({ error: 'Missing q parameter.' });
    res.json({ query, videos: await searchYouTube(query, 6) });
  })
);

app.get(
  '/api/weather',
  wrap(async (req, res) => {
    const location = String(req.query.location || '').trim();
    if (!location) return res.status(400).json({ error: 'Missing location parameter.' });
    res.json(await getWeather(location));
  })
);

app.get('/api/tools', (req, res) => res.json({ tools: toolSchemas() }));

// Error handler.
app.use((err, req, res, next) => {
  const status = err.statusCode || 500;
  if (status >= 500) console.error('[lily] error:', err.message);
  res.status(status).json({ error: err.message || 'Something went wrong.' });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`\n  Lily is awake on http://localhost:${PORT}`);
    console.log(`  Groq key ${apiKey() ? 'loaded' : 'MISSING - check .env'}\n`);
  });
}

module.exports = app;
