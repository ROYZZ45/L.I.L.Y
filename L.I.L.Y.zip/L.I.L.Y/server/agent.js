'use strict';

const { chat } = require('./groq');
const { toolSchemas, clientToolNames } = require('./tools');
const { webSearch, searchYouTube, getWeather, wikipediaSummary } = require('./web');

const MAX_TOOL_ROUNDS = 6;
const MAX_HISTORY = 16;

const SYSTEM_PROMPT = `You are Lily, a warm, concise voice assistant that lives inside a glowing orb on the user's screen.

Your voice: speak like a person, not a manual. One or two short sentences unless the user asks for detail. No markdown, no bullet lists, no emoji, no asterisks - your words are read aloud by a speech synthesiser, so write them to be heard.

Your capabilities:
- Answer general questions using your own knowledge.
- Use the search_web tool for anything current, factual or unfamiliar to you.
- Use get_weather for weather and get_wikipedia_summary for encyclopedic facts.
- Use open_tab to open a website for the user, play_youtube to play a video, set_timer to start a countdown, and look_at_camera to see what the user's camera is pointing at.

Rules:
- When the user asks you to play, open, show or search something, call the matching tool. Do not pretend the action happened - only claim it after the tool confirms it.
- Each action should be requested once. After a tool result comes back, do not ask for the same action again - use the result and answer the user.
- If a tool fails, tell the user plainly and suggest an alternative.
- Call look_at_camera whenever the user refers to what they are seeing, holding, showing or pointing at.
- Keep answers short enough to be spoken comfortably.`;

function log(...args) {
  console.log('[lily]', ...args);
}

/** Execute a server-side tool and return a plain object result. */
async function runServerTool(name, args) {
  switch (name) {
    case 'search_web': {
      const results = await webSearch(args.query, 5);
      return { query: args.query, count: results.length, results };
    }
    case 'get_weather': {
      return await getWeather(args.location);
    }
    case 'get_wikipedia_summary': {
      const summary = await wikipediaSummary(args.topic);
      if (!summary) return { topic: args.topic, found: false, extract: 'No summary found for that topic.' };
      return { topic: args.topic, found: true, ...summary };
    }
    case 'play_youtube': {
      // Also resolved server-side so the model gets real titles to talk about.
      const videos = await searchYouTube(args.query, 3);
      return { query: args.query, videos };
    }
    default:
      return { error: `Unknown tool ${name}` };
  }
}

function parseArgs(raw) {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

/** Stable key for a tool call, used to detect repeat requests. */
function callKey(name, args) {
  return `${name}:${JSON.stringify(args)}`;
}

/** Convert a model tool call into the action payload the browser receives. */
function buildClientAction(toolCall) {
  const name = toolCall.function.name;
  const args = parseArgs(toolCall.function.arguments);
  return {
    toolCallId: toolCall.id,
    name,
    args,
    url: name === 'open_tab' ? args.url : undefined,
    query: args.query,
    seconds: args.seconds,
    label: args.label,
    question: args.question,
  };
}

/**
 * Conversation state per browser session. `messages` holds the transcript
 * without the system prompt, so a client-side tool round-trip can resume
 * exactly where the model left off.
 */
const sessions = new Map();

function getSession(sessionId) {
  const id = sessionId || 'default';
  if (!sessions.has(id)) sessions.set(id, { messages: [], doneCalls: new Map() });
  return sessions.get(id);
}

function trimSession(session) {
  if (session.messages.length > MAX_HISTORY) {
    session.messages = session.messages.slice(-MAX_HISTORY);
  }
  // Keep the repeat-detection map bounded.
  if (session.doneCalls.size > 40) {
    session.doneCalls = new Map([...session.doneCalls].slice(-20));
  }
}

function resetSession(sessionId) {
  sessions.delete(sessionId || 'default');
}

/**
 * Run the assistant turn.
 *
 * @param {object} options
 * @param {string} options.message        The user's utterance.
 * @param {string} options.sessionId      Browser session identifier.
 * @param {Array}  options.actionResults  Results the browser produced for pending client tools.
 */
async function runTurn({ message, sessionId, actionResults = [] }) {
  const clientNames = clientToolNames();
  const session = getSession(sessionId);
  const tools = toolSchemas();

  if (actionResults.length) {
    // Phase 2 - the browser is handing back results for tools we asked it to run.
    for (const result of actionResults) {
      session.messages.push({
        role: 'tool',
        tool_call_id: result.toolCallId,
        content: typeof result.result === 'string' ? result.result : JSON.stringify(result.result ?? {}),
      });
    }
  } else if (message) {
    // A fresh instruction means previous actions may be repeated.
    session.messages.push({ role: 'user', content: message });
    session.doneCalls.clear();
  }

  for (let round = 0; round < MAX_TOOL_ROUNDS; round += 1) {
    const reply = await chat([{ role: 'system', content: SYSTEM_PROMPT }, ...session.messages], {
      tools,
      temperature: 0.3,
      maxTokens: 700,
    });
    session.messages.push(reply);

    const toolCalls = reply.tool_calls || [];
    if (!toolCalls.length) {
      trimSession(session);
      return { status: 'done', reply: (reply.content || '').trim() };
    }

    const clientCalls = toolCalls.filter((c) => clientNames.includes(c.function.name));
    const serverCalls = toolCalls.filter((c) => !clientNames.includes(c.function.name));

    // Run every server-side tool first and feed the results straight back.
    for (const call of serverCalls) {
      const name = call.function.name;
      const args = parseArgs(call.function.arguments);
      log('tool', name, JSON.stringify(args));
      let result;
      try {
        result = await runServerTool(name, args);
      } catch (err) {
        log('tool error', name, err.message);
        result = { error: err.message };
      }
      session.messages.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(result) });
    }

    if (clientCalls.length) {
      // If the model asks for the exact same browser action twice, answer the
      // repeat with the original result instead of looping forever.
      const repeats = clientCalls.filter((c) => {
        const key = callKey(c.function.name, parseArgs(c.function.arguments));
        if (!session.doneCalls.has(key)) {
          session.doneCalls.set(key, c.id);
          return false;
        }
        return true;
      });

      if (repeats.length) {
        for (const call of repeats) {
          const key = callKey(call.function.name, parseArgs(call.function.arguments));
          const previousId = session.doneCalls.get(key);
          session.messages.push({
            role: 'tool',
            tool_call_id: call.id,
            content: JSON.stringify({ ok: true, note: 'This action was already performed.' }),
          });
          log('skipped duplicate client tool', call.function.name, previousId);
        }
        continue;
      }

      // Hand the browser side effects over and wait for it to report back.
      const actions = clientCalls.map(buildClientAction);
      log('client tools', actions.map((a) => a.name).join(', '));
      trimSession(session);
      return { status: 'action_required', actions };
    }
  }

  trimSession(session);
  return { status: 'done', reply: 'Sorry, that took me too many steps. Could you rephrase?' };
}

module.exports = { runTurn, resetSession, SYSTEM_PROMPT };
