'use strict';

const GROQ_BASE = 'https://api.groq.com/openai/v1';

/** Number of times to retry a rate-limited or transiently failing request. */
const MAX_RETRIES = 3;

/** Wait helper (ms). */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function apiKey() {
  return process.env.GROQ_API_KEY || '';
}

function requireKey() {
  const key = apiKey();
  if (!key) {
    const err = new Error('GROQ_API_KEY is missing. Add it to your .env file and restart the server.');
    err.statusCode = 500;
    err.code = 'missing_api_key';
    throw err;
  }
  return key;
}

async function groqRequest(path, { method = 'GET', body, headers = {}, raw = false } = {}) {
  const key = requireKey();

  const init = { method, headers: { Authorization: `Bearer ${key}`, ...headers } };
  if (body instanceof FormData) {
    init.body = body; // let fetch set the multipart boundary
  } else if (body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }

  let lastError = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    let response;
    try {
      response = await fetch(`${GROQ_BASE}${path}`, init);
    } catch (err) {
      lastError = new Error(`Could not reach Groq: ${err.message}`);
      lastError.statusCode = 502;
      lastError.code = 'groq_unreachable';
      if (attempt < MAX_RETRIES) {
        await sleep(500 * 2 ** attempt);
        continue;
      }
      throw lastError;
    }

    if (response.ok) {
      if (raw) return response;
      return response.json();
    }

    const text = await response.text().catch(() => '');
    let message = `Groq request failed with status ${response.status}`;
    let code = 'groq_error';
    try {
      const parsed = JSON.parse(text);
      if (parsed && parsed.error) {
        message = parsed.error.message || message;
        code = parsed.error.code || code;
      }
    } catch {
      if (text) message = text.slice(0, 300);
    }

    // Rate limits and server errors are worth retrying.
    const retryable = response.status === 429 || response.status >= 500;
    if (retryable && attempt < MAX_RETRIES) {
      const retryAfter = Number(response.headers.get('retry-after')) || 0;
      const wait = retryAfter ? retryAfter * 1000 : 800 * 2 ** attempt;
      console.warn(`[lily] groq ${response.status}, retrying in ${wait}ms`);
      await sleep(wait);
      lastError = new Error(message);
      lastError.statusCode = response.status === 429 ? 429 : 502;
      lastError.code = code;
      continue;
    }

    const err = new Error(message);
    err.statusCode = response.status === 429 ? 429 : 502;
    err.code = code;
    throw err;
  }

  throw lastError || new Error('Groq request failed');
}

/** Chat completion that can request tool calls from the model. */
async function chat(messages, { tools, toolChoice, temperature = 0.3, maxTokens = 800, model } = {}) {
  const payload = {
    model: model || process.env.GROQ_CHAT_MODEL || 'qwen/qwen3.8-27b',
    messages,
    temperature,
    max_tokens: maxTokens,
  };
  if (tools && tools.length) {
    payload.tools = tools;
    payload.tool_choice = toolChoice || 'auto';
  }
  const json = await groqRequest('/chat/completions', { method: 'POST', body: payload });
  return json.choices?.[0]?.message || { role: 'assistant', content: '' };
}

/** Transcribe an audio blob (webm/opus, wav, mp4 ...) into text. */
async function transcribe(audioBuffer, { filename = 'audio.webm', mimeType = 'audio/webm', language, prompt } = {}) {
  const form = new FormData();
  const ext = filename.includes('.') ? filename.split('.').pop() : 'webm';
  form.append('file', new Blob([audioBuffer], { type: mimeType }), filename.endsWith('.' + ext) ? filename : `audio.${ext}`);
  form.append('model', process.env.GROQ_STT_MODEL || 'whisper-large-v3-turbo');
  form.append('response_format', 'json');
  if (language) form.append('language', language);
  if (prompt) form.append('prompt', prompt);

  const json = await groqRequest('/audio/transcriptions', { method: 'POST', body: form });
  return (json.text || '').trim();
}

/** Describe an image with the vision-capable chat model. */
async function describeImage({ imageUrl, question, maxTokens = 200 }) {
  const payload = {
    model: process.env.GROQ_VISION_MODEL || process.env.GROQ_CHAT_MODEL || 'qwen/qwen3.8-27b',
    max_tokens: maxTokens,
    temperature: 0.3,
    messages: [
      {
        role: 'user',
        content: [
          { type: 'text', text: question || 'Describe what is in this image in one short sentence.' },
          { type: 'image_url', image_url: { url: imageUrl } },
        ],
      },
    ],
  };
  const json = await groqRequest('/chat/completions', { method: 'POST', body: payload });
  return (json.choices?.[0]?.message?.content || '').trim();
}

/** Text-to-speech. Returns { audio: Buffer, contentType }. */
async function speak(text, { voice, model, responseFormat = 'wav' } = {}) {
  const payload = {
    model: model || process.env.GROQ_TTS_MODEL || 'canopylabs/orpheus-v1-english',
    input: text,
    voice: voice || process.env.GROQ_TTS_VOICE || 'austin',
    response_format: responseFormat,
  };
  const response = await groqRequest('/audio/speech', { method: 'POST', body: payload, raw: true });
  const audio = Buffer.from(await response.arrayBuffer());
  return { audio, contentType: response.headers.get('content-type') || 'audio/wav' };
}

module.exports = { chat, transcribe, speak, describeImage, groqRequest, apiKey };
