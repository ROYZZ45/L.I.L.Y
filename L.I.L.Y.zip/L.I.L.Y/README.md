# 🌸 Lily — AI Voice Assistant

A voice-first AI assistant in the browser. Lily lives in a glowing orb at the
centre of the screen, listens for the wake word **“Hey Lily”**, answers your
questions out loud, and can actually *do* things: open new tabs, search the
web, play videos on YouTube, start timers, and look through your camera to
identify objects.

Everything runs on your machine except the model calls, which go to
[Groq](https://console.groq.com) — so responses are near-instant.

---

## ✨ Features

| | |
|---|---|
| 🎤 **Wake word** | Say “Hey Lily” to wake her. Continuous background listening with voice-activity detection. |
| 🗣️ **Full conversation** | Speech-to-text in, speech out. Ask follow-up questions — she remembers the thread. |
| 🧠 **Answers questions** | Backed by Groq's `qwen/qwen3.8-27b`, with live web search when a question needs it. |
| 🌐 **Opens new tabs** | “Hey Lily, open Wikipedia” → a real new browser tab. |
| 🔍 **Searches the web** | “Hey Lily, search for the latest Mars news” → live Bing results, summarised. |
| ▶️ **Plays YouTube** | “Hey Lily, play Despacito on YouTube” → plays inline in the app. |
| 📷 **Live camera + detection** | Real-time object detection on-device (TensorFlow.js / COCO-SSD). Bounding boxes drawn over the feed. |
| 👀 **Sees what you see** | “Hey Lily, what am I holding?” → she describes the camera frame via a vision model. |
| ⏱️ **Timers** | “Hey Lily, set a timer for 10 minutes”. |
| 🌦️ **Weather** | “Hey Lily, what's the weather in Mumbai?”. |

---

## 🚀 Getting started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure your API key

Your key lives in `.env` (already created — edit it if you want a different key):

```env
GROQ_API_KEY=gsk_...
GROQ_CHAT_MODEL=qwen/qwen3.8-27b
GROQ_STT_MODEL=whisper-large-v3-turbo
GROQ_TTS_MODEL=canopylabs/orpheus-v1-english
GROQ_TTS_VOICE=austin
PORT=3000
```

> **Important:** the key stays on the server. The browser talks to
> `http://localhost:3000`, and the server talks to Groq. Your key is never
> sent to the page.

### 3. Run it

```bash
npm start
```

Open **http://localhost:3000**, click anywhere once to grant microphone access,
then say:

> “Hey Lily, what is the capital of France?”

---

## 🎙️ How the wake word works

1. A `MediaRecorder` captures audio continuously in the background.
2. Every ~700 ms the rolling buffer is sent to Groq Whisper for transcription.
3. If the transcript contains “hey lily” (or a close variant like “hey lie”),
   Lily switches into **capture mode**, discards the audio before the wake
   word, and starts listening for your actual command.
4. A Web Audio RMS level meter watches for ~1.6 s of silence — that's your cue
   to stop talking — and the command is sent.
5. The model replies, and Lily speaks the answer back.

---

## 🔧 Architecture

```
d:\L.I.L.Y
├── server/
│   ├── index.js      Express app + REST API
│   ├── agent.js      The assistant turn loop (tool calling)
│   ├── groq.js       Groq client: chat, transcribe, speech, vision
│   ├── tools.js      Tool definitions (the model's action set)
│   └── web.js        Search / YouTube / Wikipedia / weather scraping
├── public/
│   ├── index.html    The interface
│   ├── style.css     Dark minimalist theme + glowing orb
│   └── js/
│       ├── core.js       State, DOM refs, API helper, wake-word matching
│       ├── voice.js      Microphone, wake word loop, speech output
│       ├── vision.js     Camera + TF.js object detection
│       ├── actions.js    Browser-side tools (tab, YouTube, timer, camera)
│       └── app.js        Turn loop + control wiring
└── test/run.js       Backend smoke tests
```

### The tool set

| Tool | Runs on | What it does |
|---|---|---|
| `open_tab` | browser | Opens a URL in a new tab |
| `play_youtube` | browser | Searches YouTube and plays the top hit inline |
| `set_timer` | browser | Starts a countdown with a spoken finish |
| `look_at_camera` | browser | Grabs a frame and asks the vision model about it |
| `search_web` | server | Live Bing results (title, URL, snippet) |
| `get_weather` | server | Current conditions via wttr.in |
| `get_wikipedia_summary` | server | Encyclopedic extract |

Browser-side tools work in two phases: the server asks for the action, the
browser performs it and posts the result back, then the model writes its final
spoken reply using that result. Repeat requests for an action that already
happened are auto-fulfilled instead of looping.

---

## 🧪 Tests

```bash
npm test
```

Covers the health check, web search, YouTube search, weather, general chat,
each of the three browser-side tools, the resume-after-action flow, the vision
endpoint, and input validation.

---

## ⚙️ Notes & limitations

- **Speech output** uses the browser's built-in Speech Synthesis API by
  default, so it works with no extra setup. A server-side Groq TTS endpoint
  (`POST /api/tts`) is also wired up for `canopylabs/orpheus-v1-english` —
  but Groq requires an org admin to accept that model's terms first
  (https://console.groq.com/playground?model=canopylabs%2Forpheus-v1-english).
- **Voice output quality** therefore depends on the voices your OS/browser
  offers. Chrome and Edge have the best support.
- **Wake-word detection** uses cloud transcription, so it needs a network
  round-trip (~200–400 ms). It is deliberately simple rather than a
  low-latency on-device wake-word engine.
- **Object detection** is COCO-SSD (80 classes: people, animals, vehicles,
  electronics…). The model (~18 MB) is fetched from Google's CDN on first use
  and cached by the browser.
- **Search** uses Bing HTML scraping, which is more fragile than a paid API.
  DuckDuckGo's HTML endpoint returns a CAPTCHA for server requests, so Bing is
  used instead.
- **Camera and microphone** require a secure context — `localhost` works fine,
  but a LAN IP over plain HTTP will not.
- **Rate limits** — the Groq free tier is per-minute. The server retries 429s
  with exponential backoff, but very rapid use will still be throttled.

---

## ⚙️ Configuration

| Variable | Default | Purpose |
|---|---|---|
| `GROQ_API_KEY` | — | Required. Your Groq key. |
| `GROQ_CHAT_MODEL` | `qwen/qwen3.8-27b` | Chat + tool calling + vision. |
| `GROQ_STT_MODEL` | `whisper-large-v3-turbo` | Speech to text. |
| `GROQ_TTS_MODEL` | `canopylabs/orpheus-v1-english` | Optional TTS. |
| `GROQ_TTS_VOICE` | `austin` | TTS voice name. |
| `PORT` | `3000` | HTTP port. |

---

## 📄 License

MIT
